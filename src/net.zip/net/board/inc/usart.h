#ifndef __USART_H
#define __USART_H

#include "stm32f4xx_conf.h"

void COM1Init(u32 BaudRate);

#endif

